package com.example.accident

import android.app.DownloadManager
import android.Manifest
import android.content.ActivityNotFoundException
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Looper
import android.content.ContentValues
import android.content.res.Configuration
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.print.PrintAttributes
import android.print.PrintManager
import android.provider.DocumentsContract
import android.provider.MediaStore
import android.util.Base64
import android.webkit.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import java.io.File

class MainActivity : AppCompatActivity() {
    private lateinit var wv: WebView
    private var pw: WebView? = null
    private var cb: ValueCallback<Array<Uri>>? = null
    private var camUri: Uri? = null

    private val launcher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val res: Array<Uri>? = if (r.resultCode == RESULT_OK) {
            val d = r.data?.data
            if (d != null) arrayOf(d) else camUri?.let { arrayOf(it) }
        } else null
        cb?.onReceiveValue(res); cb = null
    }

    private fun js(code: String) = runOnUiThread { wv.evaluateJavascript(code, null) }

    private fun mimeOf(name: String) = when (name.substringAfterLast('.')) {
        "jpg" -> "image/jpeg"; "png" -> "image/png"; "pdf" -> "application/pdf"
        "docx" -> "application/vnd.openxmlformats-officedocument.wordprocessingml.document"; "doc" -> "application/msword"; else -> "text/html"
    }

    private fun store(folder: String, name: String, bytes: ByteArray): Uri? = try {
        val dir = folder.replace(Regex("[\\\\/:*?\"<>|]"), "-")
        val v = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, name)
            put(MediaStore.MediaColumns.MIME_TYPE, mimeOf(name))
            put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/تصادفات/" + dir)
        }
        val u = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v)!!
        contentResolver.openOutputStream(u)!!.use { it.write(bytes) }
        u
    } catch (e: Exception) { null }

    private fun openUri(u: Uri, mime: String) {
        try { startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(u, mime).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)) }
        catch (e: ActivityNotFoundException) { js("onSaved('فایل ذخیره شد ولی برنامه‌ای برای باز کردن آن نصب نیست (Downloads/تصادفات)')") }
    }

    private val locPerm = registerForActivityResult(ActivityResultContracts.RequestPermission()) { if (it) fetchLoc() }

    private fun fetchLoc() {
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) { locPerm.launch(Manifest.permission.ACCESS_FINE_LOCATION); return }
        val lm = getSystemService(LOCATION_SERVICE) as LocationManager
        val last = listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER).mapNotNull { p -> try { lm.getLastKnownLocation(p) } catch (e: Exception) { null } }.maxByOrNull { it.time }
        if (last != null) { js("onLoc(${last.latitude},${last.longitude})"); return }
        val prov = if (lm.isProviderEnabled(LocationManager.GPS_PROVIDER)) LocationManager.GPS_PROVIDER else LocationManager.NETWORK_PROVIDER
        try {
            lm.requestSingleUpdate(prov, object : LocationListener {
                override fun onLocationChanged(l: Location) { js("onLoc(${l.latitude},${l.longitude})") }
                override fun onProviderEnabled(p: String) {}
                override fun onProviderDisabled(p: String) {}
                @Deprecated("Deprecated in Java") override fun onStatusChanged(p: String?, s: Int, e: Bundle?) {}
            }, Looper.getMainLooper())
        } catch (e: Exception) {}
    }

    private fun applyTheme() {
        val night = (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
        wv.setBackgroundColor(if (night) 0xFF12171D.toInt() else 0xFFF3F5F7.toInt())
        js("document.documentElement.setAttribute('data-theme','${if (night) "dark" else "light"}')")
    }

    override fun onConfigurationChanged(newConfig: Configuration) { super.onConfigurationChanged(newConfig); applyTheme() }

    inner class Bridge {
        @JavascriptInterface fun getLocation() = runOnUiThread { fetchLoc() }

        @JavascriptInterface fun fingerprint(k: String) = runOnUiThread {
            val ok = BiometricManager.from(this@MainActivity).canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_WEAK)
            if (ok != BiometricManager.BIOMETRIC_SUCCESS) { js("onFp('$k',false,'اثر انگشت در گوشی فعال نیست')"); return@runOnUiThread }
            val bp = BiometricPrompt(this@MainActivity, ContextCompat.getMainExecutor(this@MainActivity),
                object : BiometricPrompt.AuthenticationCallback() {
                    override fun onAuthenticationSucceeded(r: BiometricPrompt.AuthenticationResult) { js("onFp('$k',true,'')") }
                    override fun onAuthenticationError(c: Int, m: CharSequence) { js("onFp('$k',false,'${m.toString().replace("'", " ")}')") }
                })
            bp.authenticate(BiometricPrompt.PromptInfo.Builder().setTitle("تایید با اثر انگشت")
                .setNegativeButtonText("لغو").setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_WEAK).build())
        }

        @JavascriptInterface fun saveFile(folder: String, name: String, b64: String): Boolean =
            store(folder, name, Base64.decode(b64, Base64.DEFAULT)) != null

        @JavascriptInterface fun saveAndOpen(folder: String, name: String, b64: String) = runOnUiThread {
            val u = store(folder, name, Base64.decode(b64, Base64.DEFAULT))
            if (u == null) js("onSaved('خطا در ذخیره')") else { js("onSaved('ذخیره شد: Downloads/تصادفات')"); openUri(u, mimeOf(name)) }
        }

        @JavascriptInterface fun savePdf(html: String, folder: String, name: String) = runOnUiThread {
            val w = WebView(this@MainActivity); pw = w
            w.webViewClient = object : WebViewClient() {
                override fun onPageFinished(v: WebView, u: String) {
                    v.postDelayed({
                        val f = File(cacheDir, "r.pdf"); f.delete()
                        android.print.PdfWriter.write(v.createPrintDocumentAdapter("report"), f) { ok ->
                            if (!ok) { js("onSaved('خطا در ساخت PDF')"); return@write }
                            val uri = store(folder, name, f.readBytes())
                            if (uri == null) js("onSaved('خطا در ذخیره')") else { js("onSaved('ذخیره شد: Downloads/تصادفات')"); openUri(uri, "application/pdf") }
                        }
                    }, 1500)
                }
            }
            w.loadDataWithBaseURL(null, html, "text/html", "utf-8", null)
        }

        @JavascriptInterface fun openFolder(folder: String) = runOnUiThread {
            val dir = folder.replace(Regex("[\\\\/:*?\"<>|]"), "-")
            val uri = DocumentsContract.buildDocumentUri("com.android.externalstorage.documents", "primary:Download/تصادفات/" + dir)
            try { startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(uri, DocumentsContract.Document.MIME_TYPE_DIR)) }
            catch (e: Exception) { try { startActivity(Intent(DownloadManager.ACTION_VIEW_DOWNLOADS)) } catch (e2: Exception) {} }
        }

        @JavascriptInterface fun printHtml(html: String, name: String) = runOnUiThread {
            val w = WebView(this@MainActivity); pw = w
            w.webViewClient = object : WebViewClient() {
                override fun onPageFinished(v: WebView, u: String) {
                    v.postDelayed({
                        val at = PrintAttributes.Builder().setMediaSize(PrintAttributes.MediaSize.ISO_A4).setMinMargins(PrintAttributes.Margins.NO_MARGINS).build()
                        (getSystemService(PRINT_SERVICE) as PrintManager).print(name, v.createPrintDocumentAdapter(name), at)
                    }, 1500)
                }
            }
            w.loadDataWithBaseURL(null, html, "text/html", "utf-8", null)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        wv = WebView(this); setContentView(wv)
        wv.settings.javaScriptEnabled = true
        wv.settings.domStorageEnabled = true
        wv.settings.useWideViewPort = true
        wv.settings.loadWithOverviewMode = true
        @Suppress("DEPRECATION") wv.settings.forceDark = WebSettings.FORCE_DARK_OFF
        wv.webViewClient = object : WebViewClient() { override fun onPageFinished(v: WebView, u: String) { applyTheme() } }
        wv.addJavascriptInterface(Bridge(), "Android")
        wv.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(v: WebView, c: ValueCallback<Array<Uri>>, p: FileChooserParams): Boolean {
                cb?.onReceiveValue(null); cb = c
                val i = if (p.isCaptureEnabled) {
                    val cv = ContentValues().apply {
                        put(MediaStore.Images.Media.DISPLAY_NAME, "accident_${System.currentTimeMillis()}.jpg")
                        put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                        put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/Accidents")
                    }
                    camUri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv)
                    Intent(MediaStore.ACTION_IMAGE_CAPTURE).putExtra(MediaStore.EXTRA_OUTPUT, camUri)
                } else Intent(Intent.ACTION_GET_CONTENT).addCategory(Intent.CATEGORY_OPENABLE).setType("image/*")
                launcher.launch(i); return true
            }
        }
        wv.loadUrl("file:///android_asset/index.html")
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() { if (wv.canGoBack()) wv.goBack() else super.onBackPressed() }
}
