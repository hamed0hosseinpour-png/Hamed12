package com.example.accident

import android.content.ContentValues
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.print.PrintAttributes
import android.print.PrintManager
import android.provider.MediaStore
import android.util.Base64
import android.webkit.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {
    private lateinit var wv: WebView
    private var pw: WebView? = null
    private var cb: ValueCallback<Array<Uri>>? = null
    private var camUri: Uri? = null

    private val launcher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val res: Array<Uri>? = if (r.resultCode == RESULT_OK) {
            val d = r.data?.data
            if (d != null) arrayOf(d) else camUri?.let { arrayOf(it) }
        } else null
        cb?.onReceiveValue(res); cb = null
    }

    private fun js(code: String) = runOnUiThread { wv.evaluateJavascript(code, null) }

    inner class Bridge {
        @JavascriptInterface fun fingerprint(k: String) = runOnUiThread {
            val ok = BiometricManager.from(this@MainActivity).canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_WEAK)
            if (ok != BiometricManager.BIOMETRIC_SUCCESS) { js("onFp('$k',false,'اثر انگشت در گوشی فعال نیست')"); return@runOnUiThread }
            val bp = BiometricPrompt(this@MainActivity, ContextCompat.getMainExecutor(this@MainActivity),
                object : BiometricPrompt.AuthenticationCallback() {
                    override fun onAuthenticationSucceeded(r: BiometricPrompt.AuthenticationResult) { js("onFp('$k',true,'')") }
                    override fun onAuthenticationError(c: Int, m: CharSequence) { js("onFp('$k',false,'${m.toString().replace("'", " ")}')") }
                })
            bp.authenticate(BiometricPrompt.PromptInfo.Builder().setTitle("تایید با اثر انگشت")
                .setNegativeButtonText("لغو").setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_WEAK).build())
        }

        @JavascriptInterface fun saveFile(folder: String, name: String, b64: String): Boolean = try {
            val dir = folder.replace(Regex("[\\\\/:*?\"<>|]"), "-")
            val mime = when (name.substringAfterLast('.')) { "jpg" -> "image/jpeg"; "png" -> "image/png"; "doc" -> "application/msword"; else -> "text/html" }
            val v = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, name)
                put(MediaStore.MediaColumns.MIME_TYPE, mime)
                put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/تصادفات/" + dir)
            }
            val u = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v)!!
            contentResolver.openOutputStream(u)!!.use { it.write(Base64.decode(b64, Base64.DEFAULT)) }
            true
        } catch (e: Exception) { false }

        @JavascriptInterface fun printHtml(html: String, name: String) = runOnUiThread {
            val w = WebView(this@MainActivity); pw = w
            w.webViewClient = object : WebViewClient() {
                override fun onPageFinished(v: WebView, u: String) {
                    (getSystemService(PRINT_SERVICE) as PrintManager).print(name, v.createPrintDocumentAdapter(name), PrintAttributes.Builder().build())
                }
            }
            w.loadDataWithBaseURL(null, html, "text/html", "utf-8", null)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        wv = WebView(this); setContentView(wv)
        wv.settings.javaScriptEnabled = true
        wv.settings.domStorageEnabled = true
        wv.addJavascriptInterface(Bridge(), "Android")
        wv.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(v: WebView, c: ValueCallback<Array<Uri>>, p: FileChooserParams): Boolean {
                cb?.onReceiveValue(null); cb = c
                val i = if (p.isCaptureEnabled) {
                    val cv = ContentValues().apply {
                        put(MediaStore.Images.Media.DISPLAY_NAME, "accident_${System.currentTimeMillis()}.jpg")
                        put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                        put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/Accidents")
                    }
                    camUri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv)
                    Intent(MediaStore.ACTION_IMAGE_CAPTURE).putExtra(MediaStore.EXTRA_OUTPUT, camUri)
                } else Intent(Intent.ACTION_GET_CONTENT).addCategory(Intent.CATEGORY_OPENABLE).setType("image/*")
                launcher.launch(i); return true
            }
        }
        wv.loadUrl("file:///android_asset/index.html")
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() { if (wv.canGoBack()) wv.goBack() else super.onBackPressed() }
}
