package android.print

import android.os.CancellationSignal
import android.os.ParcelFileDescriptor
import java.io.File

object PdfWriter {
    fun write(adapter: PrintDocumentAdapter, out: File, done: (Boolean) -> Unit) {
        val attrs = PrintAttributes.Builder()
            .setMediaSize(PrintAttributes.MediaSize.ISO_A4)
            .setResolution(PrintAttributes.Resolution("pdf", "pdf", 300, 300))
            .setMinMargins(PrintAttributes.Margins.NO_MARGINS).build()
        adapter.onStart()
        adapter.onLayout(null, attrs, CancellationSignal(), object : PrintDocumentAdapter.LayoutResultCallback() {
            override fun onLayoutFinished(info: PrintDocumentInfo?, changed: Boolean) {
                try {
                    val fd = ParcelFileDescriptor.open(out, ParcelFileDescriptor.MODE_CREATE or ParcelFileDescriptor.MODE_READ_WRITE)
                    adapter.onWrite(arrayOf(PageRange.ALL_PAGES), fd, CancellationSignal(), object : PrintDocumentAdapter.WriteResultCallback() {
                        override fun onWriteFinished(pages: Array<out PageRange>?) { fd.close(); adapter.onFinish(); done(true) }
                        override fun onWriteFailed(error: CharSequence?) { fd.close(); adapter.onFinish(); done(false) }
                    })
                } catch (e: Exception) { done(false) }
            }
            override fun onLayoutFailed(error: CharSequence?) { done(false) }
        }, null)
    }
}
